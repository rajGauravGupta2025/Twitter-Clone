// Define an array of navigation links
export const navLinks = [
  {
    name: 'Home', // Name of the link displayed to users
    route: '/home', // Route the link navigates to
  },
  {
    name: 'Profile', // Name of the link displayed to users
    route: '/my-profile', // Route the link navigates to
  },
  {
    name: 'Logout', // Name of the link displayed to users
    route: '/', // Route the link navigates to
  },
];
